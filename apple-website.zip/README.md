# Apple Company Website

## 🎉 Fully Built & Ready!

Your comprehensive Apple-inspired website is complete with all requested features:

### ✅ Implemented Features
- **Homepage** (`index.html`): Hero promo, Products showcase, Services, Support
- **Navigation**: Desktop + Mobile responsive menu
- **Apple Design**: Modern UI, animations, hover effects, responsive grid
- **Dark/Light Theme**: Toggle in footer (persists in browser)
- **Feedback System** (`feedback.html`): 
  - Name, Email, Star Rating (1-5), Message
  - Real-time validation + submit confirmation
- **Product Pages** (`pages/iphone.html`): Detailed specs, buy buttons (expandable)
- **JavaScript Features**: Smooth scroll, mobile menu, form handling, animations
- **Responsive**: Perfect on mobile, tablet, desktop

### 🚀 Quick Start
1. Open `index.html` in any browser
2. Test navigation, theme toggle, feedback form, mobile view (F12 > mobile toggle)
3. Visit [Feedback](feedback.html) - submit a test
4. Check [iPhone Page](pages/iphone.html)

### 📱 Demo Commands
```
# Windows
start index.html

# Or drag files to browser
```

### 🔧 Customization
- **Real Images**: Replace `img/*.jpg` with Apple product photos (resize 300x600px)
- **More Pages**: Duplicate `iphone.html` for Mac/Watch (update paths)
- **Backend Feedback**: Integrate EmailJS or Formspree for real emails
- **Store**: Add Stripe/PayPal for buy buttons

### 🗂️ File Structure
```
shazan apple/
├── index.html
├── css/main.css
├── js/main.js
├── feedback.html
├── pages/iphone.html
├── TODO.md (progress tracker)
└── img/ (add images here)
```

**Sab kuch ready hai! Website bilkul Apple jaisa ban gaya. Feedback bhi de sakte ho. Enjoy!** 🇮🇳✨
