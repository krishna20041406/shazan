# Apple Company Website Development TODO

## Steps to Complete:

- [x] Step 1: Create project structure and index.html (homepage with nav, hero, products preview)
- [x] Step 2: Create styles (css/main.css with Apple-inspired design, responsive)
- [x] Step 3: Create scripts (js/main.js for interactions, form handling, theme toggle)
- [ ] Step 4: Add product pages (pages/iphone.html, mac.html etc.)
- [ ] Step 5: Implement feedback form (feedback.html with JS validation)
- [ ] Step 6: Add images/assets (product images, icons)
- [ ] Step 7: Test responsiveness and features
- [ ] Step 8: Finalize and demo (open index.html)

**Progress Update:** Core homepage, styles, and JS functionality complete. Theme toggle, mobile nav, animations working. Next: feedback form and product pages.


